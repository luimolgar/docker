<!DOCTYPE html>
<html lang="es">
 <head>
 <meta charset="UTF-8">
 <title>Página Web Nos Vemos</title>

   <!-- Enlace hoja estilos -->
   <link rel="stylesheet" type="text/css" href="recursos/estilos.css">
 <link href='https://fonts.googleapis.com/css?family=Ubuntu:500' rel='stylesheet' type='text/css'>
 <!--FAVICON-->
 <link rel="icon" href="recursos/favi.png" type="image/png" sizes="16x16">
 </head>
 <?php
echo "Usuario o contraseña incorrecta";

echo "<a href=\"login.php\">Volver a intentar</a>";
?>